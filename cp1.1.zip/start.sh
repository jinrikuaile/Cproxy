#!/bin/bash
clear
if [[ ! -n $(yum list installed | grep nodejs) ]];
then
echo -e "\033[31;1m检测到未安装NodeJs,回车开始安装(仅支持centos):\t\t\033[0m"
read
echo -e "\033[32;49;1m安装过程中不要进行操作\033[0m"
sleep 3
yum install -y curl
curl -sL https://rpm.nodesource.com/setup | bash -
yum install -y nodejs
clear
echo -e "\033[32;49;1m安装完成!\033[0m"
fi

ps -ef | grep cp1.1.js | grep -v grep | cut -c 9-15 | xargs kill -9 >/dev/null 2>&1
echo -e "\033[31;1m请输入 1:后台启动[回车默认]    2:前台启动\033[0m"
echo -n -e "\033[32;49;1m请选择运行模式:\t\t\033[0m"
read mode
echo ""
if [[ ! -n $mode ]];
then
echo -e "\033[32;49;1mCProxy将于后台启动\t\t\033[0m"
fi
echo -n -e "\033[32;49;1m请输入监听端口(回车默认8080):\t\t\033[0m"
read port
if [[ ! -n $port ]];
then
port=8080;
echo -e "\033[32;49;1mCProxy将监听于${port}端口\t\t\033[0m"
fi
echo ""
echo -n -e "\033[32;49;1m请输入验证头(回车默认为空):\t\t\033[0m"
read header
if [[ ! -n $header ]];
then
echo -e "\033[32;49;1mCProxy验证头将为空\t\t\033[0m"
header="";
fi
echo ""
if [[ "2" == "$mode" ]];
then
	node --expose-gc ./cp1.1.js $port $header
	exit 0
elif [[ "2" != "$mode" ]];
then
	rm -f /root/cp.log
	nohup node --expose-gc ./cp1.1.js $port $header > ./cp.log 2>&1 &
	sleep 1
	cat ./cp.log
	exit 0
fi
