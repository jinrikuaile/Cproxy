#!/bin/bash
echo -e "\033[31;1m回车结束CProxy\033[0m"
read
ps -ef | grep cp1.1.js | grep -v grep | cut -c 9-15 | xargs kill -9 >/dev/null 2>&1
exit 0
